from django.apps import AppConfig


class AppgiovanaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appGiovana'
